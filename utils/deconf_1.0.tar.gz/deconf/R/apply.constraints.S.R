`apply.constraints.S` <-
function(S2,alpha=0) {
	
     if (alpha > 0) {	
	     	S2[is.na(S2)] <- 0.01
     		corr.matrix <- cor(S2,use = "all.obs",method="spearman") 
    		corr.matrix[is.na(corr.matrix)] <- 0	
			
		#Einheitsmatrix	
		E <- matrix(0,nrow=ncol(S2),ncol=ncol(S2))
		
		#Hauptdiagonale Einsen
		for (i in 1:ncol(S2)) {
			E[i,i] <- 1
		}

     		diff <-  (alpha * S2) %*% ( corr.matrix - E)
  
     		S2 <- S2 - diff
     } 	
     S2 <- normalize.col.in.matrix(S2,col.value=1,method="mean")
     return (S2)
}

