`lsqnonneg` <-
function(C,D,X0=matrix(0,nrow=ncol(C),ncol=nrow(D)),
	error.threshold=10 * eps() * norm(C,1) * length(C))
{
      X <- c()
	col.results <- list()
	for (col in 1:ncol(X0))
	{
		col.value <- X0[,col]
		x.col <- matrix(col.value,nrow=length(col.value),ncol=1)

		col.value <- D[,col]
		d.col <- matrix(col.value,nrow=length(col.value),ncol=1)

		col.results[[col]] <- lsqnonneg.col(C,d.col,x.col,error.threshold=error.threshold)
		X <- cbind(X,col.results[[col]]$x)

	}
	res.list <- list()
	res.list[["x"]]  <- X
	res.list[["resnorm"]] <- norm(C %*% X - D)
	res.list[["col.details"]] <- col.results
	return (res.list)
}

